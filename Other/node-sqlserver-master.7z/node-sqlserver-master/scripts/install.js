var assert=require('assert');
var subprocess=require('child_process');
var package=require('../package.json');

function log( msg ) {
    console.log( "install.js: " + msg );
}
console.log( "You are installing driver locally." );

var msiName = 'C:\\Users\\ted.zhanghl\\Downloads\\msnodesql-0.2.1-v0.8-x64.msi';
// run the msi to extract the driver inside
var msiCmd = [ 'cmd', '/c', 'msiexec', '/i', msiName, '/quiet','IACCEPTMSNODESQLLICENSETERMS=Yes', 'NPMINSTALL=Yes' ].join(' ');
subprocess.exec( msiCmd, function( error, stdout, stderr ) {
    if( error !== null ) {
    log( error );
    log( stdout );
    process.exit( 1 );
    }
});